# Azure Container Website

This project is a simple static website that provides information about Azure Container Instances (ACI). It is designed to be containerized using Docker and deployed on Azure Container Instances.

## 📁 Files Included

- `index.html`: Static HTML page about Azure Container Instances
- `Dockerfile`: Docker configuration to serve the site using NGINX

## 🚀 How to Deploy

### 1. Build the Docker Image

```bash
docker build -t <your-username>/azure-container-website .
```

### 2. Push the Image to a Container Registry

You can use Docker Hub or Azure Container Registry (ACR). Example for Docker Hub:

```bash
docker push <your-username>/azure-container-website
```

### 3. Deploy to Azure Container Instances (ACI)

Replace `<your-resource-group>` and `<your-username>` appropriately:

```bash
az container create   --name azure-container-website   --resource-group <your-resource-group>   --image <your-username>/azure-container-website   --dns-name-label azure-container-site-demo   --ports 80
```

### 4. Access Your Website

Once deployed, access the website via:

```
http://azure-container-site-demo.<region>.azurecontainer.io
```

## 📚 References

- Azure Container Instances: https://learn.microsoft.com/en-us/azure/container-instances/
- Azure CLI Installation: https://learn.microsoft.com/en-us/cli/azure/install-azure-cli
- Azure Container Registry: https://learn.microsoft.com/en-us/azure/container-registry/